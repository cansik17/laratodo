
  <?php if(session()->has("message")): ?>
  <script>
     	Toast.fire({
        icon: "info",
        title: "<?php echo e(session("message")); ?>"
      })
</script>
<?php endif; ?>

<?php /**PATH C:\Users\blego\OneDrive\Desktop\laravel\laratodo\resources\views/partials/alert.blade.php ENDPATH**/ ?>
<?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr>
    <td class="<?php echo e($item->is_read == 1 ? "note-read" : ""); ?>"><?php echo e($item->note); ?></td>
    <td><?php echo e(getCategoriesName($item->id)); ?></td>
    <td><?php echo e(getDateForHumans($item->due_date)); ?></td>
    <td><?php echo e($item->created_at); ?> by <?php echo e($item->user_id); ?></td>
    <td>
        <label class="switch">
            <input type="checkbox" class="toggleStatus" data-url="/toggle-status/<?php echo e($item->id); ?>"
                <?php echo e($item->is_read == 1 ? "checked" : ""); ?> />
            <span class="slider round"></span>
        </label>
    </td>
    <td>
        <a href="#" data-href="/<?php echo e($item->id); ?>" class="btn btn-sm btn-danger removeBtn"><i
                class="fa-solid fa-times"></i></a>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<tr>
    No Data
</tr>
<?php endif; ?>

<script>
    $(".toggleStatus").click(function (e) {
        //e.preventDefault();
        let val = $(this).prop("checked")
        let action = $(this).data("url")
        let elem = $(this).parents("tr").find("td:first-child")
        console.log(elem)
        if (typeof val !== "undefined" && typeof action !== "undefined") {

            $.ajax({
                type: "PUT",
                url: action,
                data: {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    val: val
                },
                dataType: "json",
                success: function (response) {
                    if (response.type == "success") {
                        // Toast.fire({
                        //     icon: response.type,
                        //     title: response.message
                        // })
                        if (elem.hasClass("note-read")) {
                            elem.removeClass("note-read")
                        } else {
                            elem.addClass("note-read")
                        }

                        renderList()

                    } else {
                        Toast.fire({
                            icon: response.type,
                            title: response.message
                        })
                    }
                }
            });

        }
    });

    $(".removeBtn").click(function (e) {
        e.preventDefault();
        let action = $(this).data("href")
        let element = $(this).parents("tr")
        let text = "Are you sure?";

        if (confirm(text) == true) {
            $.ajax({
                type: "DELETE",
                url: action,
                data: {
                    "_token": "<?php echo e(csrf_token()); ?>"
                },
                dataType: "json",
                success: function (response) {
                    if (response.type == "success") {
                        //alert(response.message)
                        $(element).remove()
                    } else {
                        alert(response.message)
                    }
                }
            });
        }
    });

    $('#pagination-twbs').attr("data-total",<?php echo e($paginationArr["totalPages"]); ?>)
    $('#pagination-twbs').attr("data-current",<?php echo e($paginationArr["currentPage"]); ?>)


</script>
<?php /**PATH C:\Users\blego\OneDrive\Desktop\laravel\laratodo\resources\views/notes/components/renderList.blade.php ENDPATH**/ ?>
<?php $__env->startComponent('mail::message'); ?>
# Welcome to <?php echo e(config('app.name')); ?>


Dear <?php echo e($user->name); ?>,<br>
Please click the button below to activate your account.
<?php
    $verificationUrl = url("/")."/email-verification?email=".$user->email."&token=".$user->email_verification_token;
?>
<?php $__env->startComponent('mail::button', ['url' => $verificationUrl]); ?>
Activate my account
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\blego\OneDrive\Desktop\laravel\laratodo\resources\views/emails/emailVerification.blade.php ENDPATH**/ ?>
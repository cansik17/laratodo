<nav class="navbar navbar-expand-lg navbar-dark bg-dark" >
  <a class="navbar-brand" href="/">LaraTodo</a>
  <button class="navbar-toggler navbar-toggler-right collapsed" type="button" data-toggle="collapse" data-target="#navb" aria-expanded="false">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="navbar-collapse collapse" id="navb" style="">
    <ul class="navbar-nav ml-auto">
      <?php if(auth()->guard()->guest()): ?>
      
     
        <li class="nav-item">
          <a class="nav-link" href="/login">Login</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/register">Register</a>
        </li>   
      <?php endif; ?>
  
      <?php if(auth()->guard()->check()): ?>
        <li class="nav-item">
          <a class="nav-link" href="javascript:void(0)">Welcome <?php echo e(auth()->user()->name); ?></a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link logoutBtn" href="javascript:void(0)" data-href="/logout">Logout</a>
        </li>   
      <?php endif; ?>
   
    </ul>
 
  </div>
</nav><?php /**PATH C:\Users\blego\OneDrive\Desktop\laravel\laratodo\resources\views/partials/header.blade.php ENDPATH**/ ?>
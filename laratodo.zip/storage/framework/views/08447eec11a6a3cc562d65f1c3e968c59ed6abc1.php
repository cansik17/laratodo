
<?php $__env->startSection('title', ''); ?>
<?php $__env->startSection('content'); ?>
<div class="mt-4 mb-3">
    <h4 class="mb-1 d-inline-block mb-3">Notes </h4>
    <?php if(auth()->guard()->check()): ?>
    <button class="btn btn-info btn-sm mb-3 float-right createBtn">New</button>
    <div class="w-50 ml-auto mb-3 d-none text-div">
        <select name="categories[]" class="categoriesSelect select-multiple mb-2" multiple="multiple">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($row->id); ?>"><?php echo e($row->title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <input type="date" class="form-control dueDate mb-2" name="due_date">
        <textarea class="form-control mb-2 noteContent" rows="3"></textarea>
        <button class="btn btn-success btn-sm mb-3 float-right saveBtn" data-url="/">Add To List</button>
    </div>
    <div class="row filter-area ">
        <div class="col-md-3 ">
            <select class="categoriesSelect select-multiple mb-2 filterCategories" multiple="multiple">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($row->id); ?>"><?php echo e($row->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-3 ">
            <select class="form-control filterDueDate" >
                <option value="">Due Date Filter</option>
                <option value="expired">Expired</option>
                <option value="oneDay">1 day</option>
                <option value="threeDays">3 day</option>
                <option value="oneWeek">1 week</option>
                <option value="oneMonth">1 month</option>
                <option value="oneYear">1 year</option>
                <option value="notExpired">Not Expired</option>
            </select>
        </div>
        <div class="col-md-3 ">
            <select class="form-control filterStatus" >
                <option value="">Complete Status Filter</option>
                <option value="1">Yes</option>
                <option value="0">No</option>
            </select>
        </div>
        <div class="col-md-3 ">
            <select class="form-control filterSort" >
                <option value="">Sorting Filter</option>
                <option value="dueDateAsc">Due Date ASC</option>
                <option value="dueDateDesc">Due Date DESC</option>
                <option value="createDateAsc">Create Date ASC</option>
                <option value="createDateDesc">Create Date DESC</option>
            </select>
        </div>

    </div>


</div>
<table class="table table-striped ">
    <thead class="thead-dark">
        <tr>
            <th scope="col">Note</th>
            <th scope="col">Categories</th>
            <th scope="col">Due Date</th>
            <th scope="col">Created At</th>
            <th scope="col"></th>
            <th scope="col"></th>
        </tr>
    </thead>
    <tbody class="noteListBody">
        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td class="<?php echo e($item->is_read == 1 ? "note-read" : ""); ?>"><?php echo e($item->note); ?></td>
            <td><?php echo e(getCategoriesName($item->id)); ?></td>
            <td><?php echo e(getDateForHumans($item->due_date)); ?></td>
            <td><?php echo e(getDateForHumans($item->created_at)); ?> by <?php echo e($item->user_id); ?></td>
            <td>
                <label class="switch">
                    <input type="checkbox" class="toggleStatus" data-url="/toggle-status/<?php echo e($item->id); ?>"
                        <?php echo e($item->is_read == 1 ? "checked" : ""); ?> />
                    <span class="slider round"></span>
                </label>
            </td>
            <td>
                <a href="#" data-href="/<?php echo e($item->id); ?>" class="btn btn-sm btn-danger removeBtn"><i
                        class="fa-solid fa-times"></i></a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            No Data
        </tr>
        <?php endif; ?>

    </tbody>
</table>
<ul id="pagination-twbs" data-total="<?php echo e($paginationArr["totalPages"]); ?>" data-current="<?php echo e($paginationArr["currentPage"]); ?>"></ul>
<?php endif; ?>

<?php if(auth()->guard()->guest()): ?>
<p>You need to <a href="/login">login</a> to see your notes.</p>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\blego\OneDrive\Desktop\laravel\laratodo\resources\views/notes/index.blade.php ENDPATH**/ ?>